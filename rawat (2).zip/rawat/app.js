const express = require('express');
const mysql = require('mysql');
const app = express();
app.use(express.static('public'));
app.use(express.urlencoded({extended:false}));
const connection = mysql.createConnection({
    host: 'localhost', 
    user: 'root', 
    password: '', 
    database: 'kasir_rawat_inap', 
    port:3306
});
connection.connect((err) => {
    if (err) {
      console.error('Kesalahan koneksi:', err);
      return;
    }
    console.log('Terhubung ke database MySQL');
  });
app.get('/',(req,res)=> {
    connection.query('SELECT * FROM pasien',(error,result)=> {
        res.render('index.ejs',{data:result});
    })
});
app.get('/room',(req,res)=> {
    connection.query('SELECT * FROM kamar',(error,result)=> {
        res.render('room.ejs',{data:result});
    })
});
app.get('/delete/:id',(req,res)=> {
    connection.query('SELECT * FROM pasien',(error,result)=> {
        connection.query('DELETE FROM pasien WHERE id_pasien=?',[req.params.id],(error,resultDelete)=> {
            res.redirect('/')
        })
    })
})
app.get('/add',(req,res)=> {
    res.render('add.ejs');
})
app.post('/create',(req,res)=> {
    connection.query('insert into pasien (id_pasien,nama_pasien,usia,alamat) value (?,?,?,?)',[req.body.id,req.body.nama,req.body.usia,req.body.alamat],(errors,result)=> {
        res.redirect('/');
    })
})
app.get('/update/:id',(req,res)=> {
    connection.query('SELECT * FROM pasien WHERE id_pasien=?',[req.params.id],(error,result)=> {
        // console.log(result);
        res.render('update.ejs',{data:result[0]});
    })
});
app.post('/change/:id',(req,res)=> {
    connection.query('UPDATE pasien SET id_pasien=?,nama_pasien=?,usia=?,alamat=? WHERE id_pasien=?',[req.body.id,req.body.nama,req.body.usia,req.body.alamat,req.params.id],(error,result)=> {
        res.redirect('/');
    })
})
app.get('/kamar',(req,res)=>{
    connection.query('SELECT administrasi.id_adm, administrasi.tagihan, pasien.nama_pasien, pasien.alamat, kamar.no_kamar,kamar.nama_kamar FROM administrasi, pasien,kamar WHERE administrasi.id_pasien= pasien.id_pasien && administrasi.no_kamar=kamar.no_kamar',(error,result)=>{
        res.render('kamar.ejs',{data:result});
    })
// app.get('/room',(req,res)=> {
//     connection.query('SELECT *from kamar',(error,result)=>{
    
//     res.render('room.ejs',{data:result});
// })

    // app.get('/room',(req,res)=> {
    // connection.query('SELECT * FROM kamar',(error,result)=> {
    //    res.render('room.ejs',{data:result});


})














app.listen(3000,()=> {
    console.log('port berjalan')
});